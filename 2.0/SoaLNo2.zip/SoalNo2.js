const hitungVolumeBalok = (a, b, c) => {
    return (a * b * c)
};

const LuasPermukaanBalok = (a, b , c) => {
    return ( 2 * (a * b + a * c + b * c))
}

document.write("Panjang : 12 <br>");
document.write("Lebar : 5 <br>");
document.write("Tinggi : 12 <br>");
document.write("Volume Balok : " + hitungVolumeBalok(12, 5, 12) + "<br>");
document.write("Luas Permukaan Balok : " + LuasPermukaanBalok(12, 5, 12));
