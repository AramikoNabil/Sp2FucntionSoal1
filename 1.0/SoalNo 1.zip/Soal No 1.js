function hitungLuasPersegiPanjang(a, b) {
  document.write("Panjang : 12cm <br> Lebar : 5 cm </br> ");
  document.write("Luas Persegi Panjang = " + a * b);
  
}

hitungLuasPersegiPanjang(12 ,5);
